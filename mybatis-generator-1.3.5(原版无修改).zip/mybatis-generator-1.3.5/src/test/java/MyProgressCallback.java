/**
 *    Copyright ${license.git.copyrightYears} the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
import org.mybatis.generator.api.ProgressCallback;

import java.text.MessageFormat;

/**
 * 处理回调消息类
 * @create 2017-10-12
 **/
public class MyProgressCallback implements ProgressCallback {
    @Override
    public void introspectionStarted(int totalTasks) {
        System.out.println(MessageFormat.format("反向数据库任务数={0} ",totalTasks));
    }

    @Override
    public void generationStarted(int totalTasks) {
        System.out.println(MessageFormat.format("生成任务数={0} ",totalTasks));
    }

    @Override
    public void saveStarted(int totalTasks) {
        System.out.println(MessageFormat.format("待保存文件 {0} 个",totalTasks));
    }

    @Override
    public void startTask(String taskName) {
        System.out.println(MessageFormat.format("启动任务：{0} ",taskName));
    }

    @Override
    public void done() {
        System.out.println("所有生成已完成");
    }

    @Override
    public void checkCancel() throws InterruptedException {
        System.out.println("checkCancel");
    }
}
