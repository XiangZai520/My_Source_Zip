/**
 *    Copyright ${license.git.copyrightYears} the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

import grass.conf.ConfigUtils;
import org.junit.Test;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class MyTest {

    /**
     * 生成 mybatis 代码
     *
     * @throws Exception
     */
//    @Test(expected = InvalidConfigurationException.class)
    @Test
    public void testGenerateMyBatis3() {
        MyConfig myConfig = ConfigUtils.getConfig(MyConfig.class);
        try {

            System.out.println("准备生成...");
            List<String> warnings = new ArrayList<String>();
            ConfigurationParser cp = new ConfigurationParser(warnings);
            //加载配置文件
            Configuration config = cp.parseConfiguration(this.getClass().getClassLoader().getResourceAsStream("MyConfigMyBatis3.xml"));

            DefaultShellCallback shellCallback = new DefaultShellCallback(true);

            MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, shellCallback, warnings);
            //开始生成代码
            //myBatisGenerator.generate(null); //生成时无进度显示
            MyProgressCallback callback = new MyProgressCallback();
            myBatisGenerator.generate(callback);
        } catch (Exception e) {
            System.out.println("出现异常...");
            e.printStackTrace();
        }finally {
            System.out.println(MessageFormat.format("文件保存目录：{0}"
                    ,myConfig.getTargetProject()));
            System.out.println(MessageFormat.format("实体类包名：{0}"
                    ,myConfig.getModelPackage()));
            System.out.println(MessageFormat.format("接口类包名：{0}"
                    ,myConfig.getDaoMapperPackage()));
            System.out.println(MessageFormat.format("xml文件名：{0}"
                    ,myConfig.getsqlMapperPackage()));
        }
    }

}
