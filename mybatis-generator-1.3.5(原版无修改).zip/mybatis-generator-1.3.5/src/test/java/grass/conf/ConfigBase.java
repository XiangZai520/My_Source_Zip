/**
 *    Copyright ${license.git.copyrightYears} the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package grass.conf;

import grass.utils.ResourceUtils;

import java.io.InputStream;
import java.util.Properties;

/**
 * 配置类的基类
 *
 * @author junpeng.chen
 */
public abstract class ConfigBase {
    protected String fileName;
    protected Properties properties = new Properties();

    public String getFileName() {
        return fileName;
    }

    public abstract void setFileName();

    public void load() {
        setFileName();
        try {
            InputStream inputStream = ResourceUtils.getDefaultClassLoader().getResourceAsStream(fileName);
            if (inputStream != null) {
                properties.load(inputStream);
            }
        } catch (Throwable e) {
            System.err.println("配置文件" + getFileName() + "加载失败");
            e.printStackTrace();
        }
    }

    public String getPropertyString(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public String getPropertyString(String key) {
        return properties.getProperty(key);
    }

    public int getPropertyInt(String key) {
        String value = getPropertyString(key);
        return Integer.parseInt(value);
    }

    public int getPropertyInt(String key, int defaultValue) {
        int value = defaultValue;
        try {
            value = getPropertyInt(key);
        } catch (Throwable ignored) {
//            ignored.printStackTrace();
        }
        return value;
    }

    public boolean getPropertyBool(String key, boolean defaultValue) {
        String strValue = getPropertyString(key);
        boolean boolValue = defaultValue;
        try {
            boolValue = Boolean.parseBoolean(strValue);
        } catch (Throwable ignored) {
//            ignored.printStackTrace();
        }
        return boolValue;
    }
}
