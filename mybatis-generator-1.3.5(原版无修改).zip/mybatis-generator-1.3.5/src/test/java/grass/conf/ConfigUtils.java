/**
 *    Copyright ${license.git.copyrightYears} the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package grass.conf;

import java.lang.reflect.Constructor;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 配置工具类
 *
 * @author junpeng.chen
 */
public class ConfigUtils {
    private static Map<String, ConfigBase> configMap = new ConcurrentHashMap<String, ConfigBase>();

    /**
     * 获取特定类型的配置类
     *
     * @param type 配置类的类型
     * @param <T>  配置类的类型，必须是ConfigBase的子类
     * @return 配置类
     */
    public static <T extends ConfigBase> T getConfig(Class<T> type) {
        @SuppressWarnings("unchecked") T config = (T) configMap.get(type.getName());
        if (config == null) {
            synchronized (ConfigUtils.class) {
                //noinspection unchecked
                config = (T) configMap.get(type.getName());
                if (config == null) {
                    try {
                        // 支持私有构造函数
                        Constructor<T> constructor = type.getDeclaredConstructor();
                        constructor.setAccessible(true);
//                        config = type.newInstance();
                        config = constructor.newInstance();
                        config.load();
                    } catch (Throwable e) {
                        System.err.println("反射生成配置类出错");
                        e.printStackTrace();
                    }
                    configMap.put(type.getName(), config);
                }
            }
        }
        return config;
    }
}
