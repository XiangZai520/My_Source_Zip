/**
 *    Copyright ${license.git.copyrightYears} the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package grass.conf;

public abstract class ConfigPropertyBase extends ConfigBase {
//	public abstract String getJProductServiceAddress();
//	public abstract int getJProductServiceTimeout();
//	public ServiceAgentConfig getJProductServiceConfig() {
//		return new ServiceAgentConfig(this.getJProductServiceAddress(), this.getJProductServiceTimeout());
//	}
//	public ServiceAgentConfig getJProductServiceConfig(String channel) {
//		return new ServiceAgentConfig(this.getJProductServiceAddress(), this.getJProductServiceTimeout(), channel);
//	}
//	public abstract String getProductForPartnerServiceAddress() ;
//	public abstract int getProductForPartnerServiceTimeout();
}
